/** @type {import('tailwindcss').Config} */
export default {
  content: ['./src/**/*.{astro,html,js,jsx,md,mdx,svelte,ts,tsx,vue}'],
  theme: {
    extend: {
      colors: {
        primary: '#2D3748',
        secondary: '#718096',
        accent: '#4A4E58',
        beige: {
          light: '#F5F0E8',
          DEFAULT: '#E5D6C1',
          dark: '#D4BFA6'
        }
      }
    }
  },
  plugins: []
};