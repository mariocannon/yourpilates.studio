import { defineConfig } from 'astro/config';
import tailwind from '@astrojs/tailwind';
import sitemap from '@astrojs/sitemap';
import alpinejs from '@astrojs/alpinejs';
import compress from 'astro-compress';

export default defineConfig({
  site: 'https://yourpilates.studio',
  integrations: [
    tailwind(),
    alpinejs(),
    sitemap(),
    compress({
      css: true,
      html: true,
      js: {
        minify: true,
        compress: {
          passes: 2,
          drop_console: true,
          drop_debugger: true,
          pure_funcs: ['console.log']
        }
      },
      img: true,
      svg: {
        multipass: true
      }
    })
  ],
  vite: {
    build: {
      cssMinify: true,
      minify: true,
      reportCompressedSize: false,
      modulePreload: {
        polyfill: false
      },
      rollupOptions: {
        output: {
          manualChunks(id) {
            if (id.includes('node_modules') && !id.includes('@astrojs')) {
              return 'vendor';
            }
          },
          chunkFileNames: 'assets/js/[name]-[hash].js',
          entryFileNames: 'assets/js/[name]-[hash].js',
          assetFileNames: 'assets/[ext]/[name]-[hash].[ext]',
          compact: true
        }
      },
      target: 'esnext',
      assetsInlineLimit: 4096
    }
  }
});